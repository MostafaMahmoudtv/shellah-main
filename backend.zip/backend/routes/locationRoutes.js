import express from 'express';
import { 
  getWilayas, 
    getMoughataas, 
} from '../controllers/locationController.js';

const router = express.Router();

// المستوى الأول: جلب كل الولايات
// GET /api/locations/wilayas
router.get('/wilayas', getWilayas);

// المستوى الثاني: جلب المقاطعات حسب الولاية
// GET /api/locations/wilayas/:wilaya/moughataa
router.get('/wilayas/:wilaya/moughataa',getMoughataas);
export default router;